import pygame
import random
import sys
import math
from pygame.locals import *

# Initialize pygame
pygame.init()

# Screen setup
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("GTA Online Bruteforce Hacking")

# Colors
DARK_BLUE = (25, 25, 35)
GRID_BG = (15, 15, 25)
GRID_LINE = (40, 40, 60)
WHITE = (220, 220, 220)
RED = (255, 70, 70)
GREEN = (70, 255, 70)
BLUE = (100, 150, 255)
YELLOW = (255, 220, 70)

# Fonts
title_font = pygame.font.SysFont("Arial", 48, bold=True)
main_font = pygame.font.SysFont("Consolas", 28)
info_font = pygame.font.SysFont("Arial", 20)

# Game settings
PASSWORD = "butterbut"
GRID_COLS = len(PASSWORD)
GRID_ROWS = 3
GRID_WIDTH, GRID_HEIGHT = 600, 180
CELL_WIDTH, CELL_HEIGHT = GRID_WIDTH // GRID_COLS, GRID_HEIGHT // GRID_ROWS
SCROLL_SPEED = 0.01  # Very slow speed
MAX_ATTEMPTS = 3
LETTERS_BEFORE_TARGET = 5  # Only 5 letters before target

class HackingGame:
    def __init__(self):
        self.reset_game()
        self.state = "intro"
        
    def reset_game(self):
        self.current_column = 0
        self.attempts = MAX_ATTEMPTS
        self.scroll_positions = [0] * GRID_COLS
        self.scroll_speeds = [random.uniform(0.8, 1.2) for _ in range(GRID_COLS)]
        self.captured_letters = [" "] * GRID_COLS
        self.column_data = []
        
        # Create columns with exactly 5 letters before each target
        for letter in PASSWORD:
            sequence = [random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ') 
                       for _ in range(LETTERS_BEFORE_TARGET)]
            sequence.append(letter)  # Add target letter at end
            self.column_data.append(sequence)
    
    def get_visible_letters(self, col_idx):
        """Get letters with smooth vertical positioning"""
        scroll_pos = self.scroll_positions[col_idx]
        sequence = self.column_data[col_idx]
        visible = []
        
        for row in range(GRID_ROWS):
            # Calculate position in sequence with smooth scrolling
            pos = (scroll_pos + row) % len(sequence)
            letter = sequence[int(pos)]
            is_target = (pos >= len(sequence) - 1)  # Last letter is target
            
            # Calculate vertical offset for smooth movement
            y_offset = (pos % 1) * CELL_HEIGHT
            
            visible.append({
                'letter': letter,
                'is_target': is_target,
                'y_offset': y_offset
            })
        return visible
    
    def check_capture(self):
        scroll_pos = self.scroll_positions[self.current_column]
        
        # Target is perfectly centered when fractional part is ~0.5
        if 0.45 < (scroll_pos % 1) < 0.55:
            seq_pos = scroll_pos % len(self.column_data[self.current_column])
            if seq_pos >= len(self.column_data[self.current_column]) - 1:  # Is target
                self.captured_letters[self.current_column] = PASSWORD[self.current_column]
                self.current_column += 1
                
                if self.current_column >= GRID_COLS:
                    self.state = "success"
                return True
        
        self.attempts -= 1
        if self.attempts <= 0:
            self.state = "failed"
        return False
    
    def draw_grid(self):
        # Background
        screen.fill(DARK_BLUE)
        
        # Header
        pygame.draw.rect(screen, (40, 40, 60), (0, 0, WIDTH, 80))
        title = title_font.render("BRUTEFORCE", True, BLUE)
        screen.blit(title, (WIDTH//2 - title.get_width()//2, 20))
        
        # Grid container
        grid_x, grid_y = (WIDTH - GRID_WIDTH)//2, 200
        pygame.draw.rect(screen, (30, 30, 45), (grid_x-10, grid_y-10, GRID_WIDTH+20, GRID_HEIGHT+20))
        pygame.draw.rect(screen, (60, 60, 80), (grid_x-10, grid_y-10, GRID_WIDTH+20, GRID_HEIGHT+20), 3)
        
        # Draw letters with smooth scrolling
        for col in range(GRID_COLS):
            letters = self.get_visible_letters(col)
            for row in range(GRID_ROWS):
                letter = letters[row]['letter']
                is_target = letters[row]['is_target']
                y_offset = letters[row]['y_offset']
                
                color = RED if is_target else WHITE
                x = grid_x + col * CELL_WIDTH + CELL_WIDTH//2
                y = grid_y + row * CELL_HEIGHT + y_offset + CELL_HEIGHT//2
                
                # Draw letter
                letter_surf = main_font.render(letter, True, color)
                screen.blit(letter_surf, (x - letter_surf.get_width()//2, y - letter_surf.get_height()//2))
                
                # Draw highlight on current column
                if col == self.current_column and row == 1:
                    s = pygame.Surface((CELL_WIDTH, CELL_HEIGHT), pygame.SRCALPHA)
                    alpha = int(abs(math.sin(pygame.time.get_ticks()*0.005))*100 + 100)
                    pygame.draw.rect(s, (*BLUE, alpha), (0, 0, CELL_WIDTH, CELL_HEIGHT), 3)
                    screen.blit(s, (grid_x + col * CELL_WIDTH, grid_y + CELL_HEIGHT))
        
        # Password display
        pygame.draw.rect(screen, (40, 40, 60), (WIDTH//2-250, grid_y+GRID_HEIGHT+50, 500, 60))
        pass_text = main_font.render("PASSWORD:", True, YELLOW)
        screen.blit(pass_text, (WIDTH//2-230, grid_y+GRID_HEIGHT+65))
        
        for i, char in enumerate(self.captured_letters):
            color = GREEN if char != " " else WHITE
            char_surf = main_font.render(char, True, color)
            screen.blit(char_surf, (WIDTH//2-50 + i*40, grid_y+GRID_HEIGHT+65))
            
            if i == self.current_column:
                pygame.draw.line(screen, RED,
                               (WIDTH//2-50 + i*40, grid_y+GRID_HEIGHT+90),
                               (WIDTH//2-50 + i*40 + char_surf.get_width(), grid_y+GRID_HEIGHT+90), 2)
        
        # Attempts counter
        attempts_text = main_font.render(f"ATTEMPTS: {self.attempts}", True, WHITE)
        screen.blit(attempts_text, (WIDTH//2 - attempts_text.get_width()//2, grid_y+GRID_HEIGHT+140))
        
        # Instructions
        if self.state == "playing":
            instr = info_font.render("Press SPACE when red letter is centered in highlighted box", True, WHITE)
            screen.blit(instr, (WIDTH//2 - instr.get_width()//2, grid_y-40))
    
    def update(self):
        if self.state == "playing":
            for i in range(GRID_COLS):
                self.scroll_positions[i] += SCROLL_SPEED * self.scroll_speeds[i]
    
    def draw_intro(self):
        self.draw_grid()
        
        # Overlay
        s = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        s.fill((0, 0, 0, 180))
        screen.blit(s, (0, 0))
        
        title = title_font.render("BRUTEFORCE HACKING", True, BLUE)
        screen.blit(title, (WIDTH//2 - title.get_width()//2, HEIGHT//2-100))
        
        start = main_font.render("Press SPACE to begin", True, YELLOW)
        screen.blit(start, (WIDTH//2 - start.get_width()//2, HEIGHT//2+50))
        
        pass_hint = info_font.render(f"Password: {PASSWORD}", True, GREEN)
        screen.blit(pass_hint, (WIDTH//2 - pass_hint.get_width()//2, HEIGHT//2+120))
    
    def draw_success(self):
        self.draw_grid()
        
        # Overlay
        s = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        s.fill((0, 0, 0, 180))
        screen.blit(s, (0, 0))
        
        pygame.draw.rect(screen, (20, 40, 30), (WIDTH//2-200, HEIGHT//2-100, 400, 200))
        pygame.draw.rect(screen, GREEN, (WIDTH//2-200, HEIGHT//2-100, 400, 200), 3)
        
        success = title_font.render("ACCESS GRANTED", True, GREEN)
        screen.blit(success, (WIDTH//2 - success.get_width()//2, HEIGHT//2-50))
        
        restart = main_font.render("Press R to restart", True, WHITE)
        screen.blit(restart, (WIDTH//2 - restart.get_width()//2, HEIGHT//2+50))
    
    def draw_failed(self):
        self.draw_grid()
        
        # Overlay
        s = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        s.fill((0, 0, 0, 180))
        screen.blit(s, (0, 0))
        
        pygame.draw.rect(screen, (40, 20, 20), (WIDTH//2-200, HEIGHT//2-100, 400, 200))
        pygame.draw.rect(screen, RED, (WIDTH//2-200, HEIGHT//2-100, 400, 200), 3)
        
        failed = title_font.render("ACCESS DENIED", True, RED)
        screen.blit(failed, (WIDTH//2 - failed.get_width()//2, HEIGHT//2-50))
        
        restart = main_font.render("Press R to restart", True, WHITE)
        screen.blit(restart, (WIDTH//2 - restart.get_width()//2, HEIGHT//2+50))
    
    def draw(self):
        if self.state == "intro":
            self.draw_intro()
        elif self.state == "playing":
            self.draw_grid()
        elif self.state == "success":
            self.draw_success()
        elif self.state == "failed":
            self.draw_failed()

def main():
    game = HackingGame()
    clock = pygame.time.Clock()
    
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                
                if event.key == K_SPACE:
                    if game.state == "intro":
                        game.state = "playing"
                    elif game.state == "playing":
                        game.check_capture()
                
                if event.key == K_r:
                    if game.state in ["success", "failed"]:
                        game.reset_game()
                        game.state = "playing"
        
        game.update()
        game.draw()
        pygame.display.flip()
        clock.tick(60)

if __name__ == "__main__":
    main()