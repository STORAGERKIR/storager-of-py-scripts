import pyautogui
import time

# ===== CONFIGURATION =====
SEEDS_BUTTON_POS = None    # Will be set during calibration
FIRST_SEED_POS = None      # Position of first visible seed slot
BUY_BUTTON_OFFSET = None   # (right, down) from seed to buy button
SEED_SLOT_SPACING = 40     # Vertical distance between seed slots
VISIBLE_SEED_SLOTS = 5     # Number of visible seed slots
SCROLL_AMOUNT = -50        # Tiny scroll amount (negative = down)
SPAM_CLICKS = 20           # Buy attempts per seed
CLICK_DELAY = 0.02         # Faster clicking (seconds)
PAUSE_BETWEEN_SEEDS = 1    # Pause where you can intervene (seconds)
MAX_SCROLLS = 100          # Max scrolls before reversing
# =========================

def calibrate():
    """Quick calibration process"""
    global SEEDS_BUTTON_POS, FIRST_SEED_POS, BUY_BUTTON_OFFSET
    
    print("=== QUICK CALIBRATION ===")
    input("1. Hover SEEDS button -> Enter")
    SEEDS_BUTTON_POS = pyautogui.position()
    
    # Auto-open shop
    pyautogui.click(SEEDS_BUTTON_POS)
    time.sleep(0.3)
    pyautogui.keyDown('e')
    time.sleep(1.5)  # Faster hold
    pyautogui.keyUp('e')
    time.sleep(0.5)
    
    input("2. Hover FIRST seed -> Enter")
    FIRST_SEED_POS = pyautogui.position()
    
    input("3. CLICK seed, hover BUY -> Enter")
    buy_pos = pyautogui.position()
    BUY_BUTTON_OFFSET = (buy_pos[0] - FIRST_SEED_POS[0], buy_pos[1] - FIRST_SEED_POS[1])
    print("Calibration complete!")

def turbo_buy(seed_pos):
    """Ultra-fast buying sequence"""
    pyautogui.click(seed_pos)
    time.sleep(0.1)  # Faster selection
    
    buy_pos = (
        seed_pos[0] + BUY_BUTTON_OFFSET[0],
        seed_pos[1] + BUY_BUTTON_OFFSET[1]
    )
    
    # Rapid-fire clicks
    for _ in range(SPAM_CLICKS):
        pyautogui.click(buy_pos)
        time.sleep(CLICK_DELAY)
    
    time.sleep(PAUSE_BETWEEN_SEEDS)  # Your intervention window

def scan_universe():
    """Hyper-efficient scanning with micro-scrolls"""
    scroll_direction = SCROLL_AMOUNT
    scroll_count = 0
    
    while scroll_count < MAX_SCROLLS:
        # Blitz through visible seeds
        for i in range(VISIBLE_SEED_SLOTS):
            seed_pos = (
                FIRST_SEED_POS[0],
                FIRST_SEED_POS[1] + (i * SEED_SLOT_SPACING)
            )
            turbo_buy(seed_pos)
        
        # Micro-scroll
        pyautogui.scroll(scroll_direction)
        time.sleep(0.1)  # Faster scrolling
        scroll_count += 1
        
        # Reverse direction if needed
        if scroll_count >= MAX_SCROLLS:
            scroll_direction *= -1
            scroll_count = 0

def main():
    print("Grow a Garden TURBO MODE")
    print("=======================")
    print(f"Configured for {SPAM_CLICKS} ultra-fast buys per seed")
    print(f"Micro-scrolling {abs(SCROLL_AMOUNT)}px at a time")
    print("Ctrl+C to stop\n")
    
    calibrate()
    
    try:
        while True:
            # Faster shop opening
            pyautogui.click(SEEDS_BUTTON_POS)
            pyautogui.keyDown('e')
            time.sleep(1.2)
            pyautogui.keyUp('e')
            time.sleep(0.3)
            
            scan_universe()
            
    except KeyboardInterrupt:
        print("\nTurbo buying stopped")

if __name__ == "__main__":
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0.01  # Global speed boost
    main()