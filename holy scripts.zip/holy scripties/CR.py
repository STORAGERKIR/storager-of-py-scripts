import cv2
import numpy as np
import pytesseract
from PIL import ImageGrab
import time

# Set path to Tesseract (change this if needed)
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'  # Windows example

# Screen region to capture (adjust based on your resolution)
CARD_REGION = (300, 800, 1500, 900)  # (x1, y1, x2, y2) for 1920x1080

# Known card names (for filtering misreads)
KNOWN_CARDS = ["Goblin Gang", "Fireball", "Valkyrie", "Mega Knight", "Log", "..."]  # Add more

def detect_cards():
    prev_cards = set()
    
    while True:
        # Capture screen
        screen = np.array(ImageGrab.grab(bbox=CARD_REGION))
        gray = cv2.cvtColor(screen, cv2.COLOR_BGR2GRAY)
        
        # Use OCR to detect text (card names)
        card_text = pytesseract.image_to_string(gray)
        detected_cards = [word for word in card_text.split() if word in KNOWN_CARDS]
        
        # Log new cards
        new_cards = set(detected_cards) - prev_cards
        if new_cards:
            print(f"New cards played: {', '.join(new_cards)}")
            prev_cards.update(new_cards)
        
        time.sleep(1)  # Check every second

if __name__ == "__main__":
    print("Starting Clash Royale Card Tracker...")
    detect_cards()