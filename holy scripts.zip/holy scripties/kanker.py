import os
import time
import pyautogui
import subprocess
import threading
import pygetwindow as gw
from datetime import timedelta

# ⏱ Globals
timer = 120
running = False
stop_signal = False
paused = False
log_file = "roblox_actions.log"

def is_roblox_visible():
    for window in gw.getWindowsWithTitle('Roblox'):
        if window.visible:
            return True
    return False

def log_action(action):
    with open(log_file, "a") as f:
        f.write(f"[{time.strftime('%H:%M:%S')}] {action}\n")

def launch_log_window():
    subprocess.Popen(['cmd', '/k', f'type {log_file}'])

def anti_afk_action():
    log_action("Sending SPACE key")
    pyautogui.press('space')
    time.sleep(5)
    log_action("Sending SPACE key again")
    pyautogui.press('space')

def countdown():
    global timer, running, stop_signal, paused
    while not stop_signal:
        if running:
            if is_roblox_visible():
                paused = False
                print(f"[TIMER] Time left: {str(timedelta(seconds=timer))}    ", end="\r")
                time.sleep(1)
                timer -= 1

                if timer <= 0:
                    anti_afk_action()
                    timer = 120
            else:
                if not paused:
                    print("[PAUSED] Roblox is not visible — pausing timer...     ", end="\r")
                    paused = True
                time.sleep(1)
        else:
            time.sleep(1)

def menu():
    global running, stop_signal, paused, timer

    while True:
        print("\n--- Roblox Anti-AFK ---")
        print("1. Start")
        print("2. Stop")
        print("3. Quit")
        choice = input("Choose an option: ").strip()

        if choice == '1':
            if not running:
                running = True
                paused = False
                timer = 120
                print("Anti-AFK started.")
            else:
                print("Already running.")
        elif choice == '2':
            running = False
            paused = False
            timer = 120
            print("Anti-AFK stopped.")
        elif choice == '3':
            stop_signal = True
            print("Exiting...")
            break
        else:
            print("Invalid option.")

# 🔃 Clear log
open(log_file, 'w').close()

# 🪟 Launch log CMD
launch_log_window()

# ⏱ Start background thread
threading.Thread(target=countdown, daemon=True).start()

# 🧭 Menu
menu()
